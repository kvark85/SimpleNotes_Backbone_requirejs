-- phpMyAdmin SQL Dump
-- version 4.5.4
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 07 2016 г., 21:57
-- Версия сервера: 5.6.28-76.1-beget-log
-- Версия PHP: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `l63832sl_kvark85`
--

-- --------------------------------------------------------

--
-- Структура таблицы `sn_todo`
--
-- Создание: Окт 25 2015 г., 21:19
--

DROP TABLE IF EXISTS `sn_todo`;
CREATE TABLE `sn_todo` (
  `todo_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(1024) DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sn_todo`
--

INSERT INTO `sn_todo` (`todo_id`, `user_id`, `title`, `completed`) VALUES
(1, 1, 'Buy a newspaper', 0),
(2, 1, 'To wash the dishes', 1),
(3, 2, 'Wash the car', 0),
(4, 2, 'Feed the cat', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `sn_user`
--
-- Создание: Окт 25 2015 г., 21:19
--

DROP TABLE IF EXISTS `sn_user`;
CREATE TABLE `sn_user` (
  `user_id` int(11) NOT NULL,
  `login` varchar(32) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sn_user`
--

INSERT INTO `sn_user` (`user_id`, `login`, `email`, `password`) VALUES
(1, 'aaa', NULL, '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(2, 'bbb', NULL, '51eac6b471a284d3341d8c0c63d0f1a286262a18'),
(3, 'ccc', NULL, 'fc1200c7a7aa52109d762a9f005b149abef01479');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `sn_todo`
--
ALTER TABLE `sn_todo`
  ADD PRIMARY KEY (`todo_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `sn_user`
--
ALTER TABLE `sn_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `sn_todo`
--
ALTER TABLE `sn_todo`
  MODIFY `todo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `sn_user`
--
ALTER TABLE `sn_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `sn_todo`
--
ALTER TABLE `sn_todo`
  ADD CONSTRAINT `sn_todo_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `sn_user` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
